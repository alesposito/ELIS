% DEPRECATED
%
%
function varargout = elis_cs_allocate(allocation_type, max_events, allocated)
    
	global cs_mode ELIS_CS_DATATYPE ELIS_CS_WORDLENGTH
    
    MEM_PTG = 32/8;
    MEM_UTM = 32/8;
    MEM_CHN =  8/8;
    MEM_BUF = ELIS_CS_WORDLENGTH(cs_mode)/8;
    
    supported_types                = {'buffer','data','all-data','image'};
    [issupported allocation_index] = ismember(lower(allocation_type),supported_types);
    if ~issupported
        error([mfilename '> data type not supported']);
    end
    
    if isempty(allocated), allocated=0; end
    
    [dmb memory_usage] = memory;
    memory_available   = memory_usage.PhysicalMemory.Available;
    
    
    memory_needed      = [MEM_BUF
                          MEM_PTG+MEM_UTM+MEM_CHN
                          MEM_PTG+MEM_UTM+MEM_CHN+MEM_BUF
                          0];
    
    memory_needed = (max_events-allocated)*memory_needed(allocation_index);

         
     