function prms = elis_cs_get_format(tdcId)

    global cs_mode ELIS_CS_MODE_TDC ELIS_CS_MODE_FLIM

    [err prms] = calllib('scTDC1','sc_tdc_get_format2',tdcId,elis_cs_define('sc_tdc_format'));

    switch cs_mode
        
        case ELIS_CS_MODE_TDC
            prms.ptg_offset = prms.time_tag_offset;
            prms.ptg_length = prms.time_tag_length;
            
        case ELIS_CS_MODE_FLIM
            prms.ptg_offset = prms.sign_counter_offset;
            prms.ptg_length = prms.sign_counter_length;    
    end

    
    elis_cs_check_err(err);
