% --- build-3
% - added FLIM mode, but not yet functional
% - from this build, img_prm should be passed as an argument
%   for back comatibility see build-2

function elis_cs_acquire(tdcId, acq_time, gpx3ini, img_prm)
    
    global cs_mode ELIS_CS_MODE_FLIM 

    if cs_mode == ELIS_CS_MODE_FLIM
        img_prm.pdt = (1/400) / 256; %unsigned short pixel_interval
        img_prm.ldi = 0; %unsigned int line_delay_interval ????
        img_prm_mlc = 0; %unsigned int multiline_count ???
        % last argument passed as emptu double *corr_table

        err = calllib('scTDC1','sc_tdc_set_flim_scanner2',tdcId, img_prm.pdt, img_prm.x + img_prm.rx, img_prm.y, img_prm.ldi , img_prm_mlc, []);  
    end



    err = elis_cs_check_err(calllib('scTDC1','sc_tdc_start_measure2',tdcId,acq_time));
        
    if strcmp(gpx3ini.ext_trigger,'YES')
        display('Acquisition started: waiting for trigger')
    else
        display('Acquisition started...')
    end

