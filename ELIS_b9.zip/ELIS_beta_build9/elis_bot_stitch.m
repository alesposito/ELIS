close all

LUT = [         0         0         0
    0.0333    0.0333    1.0000
    0.0667    0.0667    1.0000
    0.1000    0.1000    1.0000
    0.1333    0.1333    1.0000
    0.1667    0.1667    1.0000
    0.2000    0.2000    1.0000
    0.2333    0.2333    1.0000
    0.2667    0.2667    1.0000
    0.3000    0.3000    1.0000
    0.3333    0.3333    1.0000
    0.3667    0.3667    1.0000
    0.4000    0.4000    1.0000
    0.4333    0.4333    1.0000
    0.4667    0.4667    1.0000
    0.5000    0.5000    1.0000
    0.5333    0.5333    1.0000
    0.5667    0.5667    1.0000
    0.6000    0.6000    1.0000
    0.6333    0.6333    1.0000
    0.6667    0.6667    1.0000
    0.7000    0.7000    1.0000
    0.7333    0.7333    1.0000
    0.7667    0.7667    1.0000
    0.8000    0.8000    1.0000
    0.8333    0.8333    1.0000
    0.8667    0.8667    1.0000
    0.9000    0.9000    1.0000
    0.9333    0.9333    1.0000
    0.9667    0.9667    1.0000
    1.0000    1.0000    1.0000
    1.0000    0.9697    0.9697
    1.0000    0.9394    0.9394
    1.0000    0.9091    0.9091
    1.0000    0.8788    0.8788
    1.0000    0.8485    0.8485
    1.0000    0.8182    0.8182
    1.0000    0.7879    0.7879
    1.0000    0.7576    0.7576
    1.0000    0.7273    0.7273
    1.0000    0.6970    0.6970
    1.0000    0.6667    0.6667
    1.0000    0.6364    0.6364
    1.0000    0.6061    0.6061
    1.0000    0.5758    0.5758
    1.0000    0.5455    0.5455
    1.0000    0.5152    0.5152
    1.0000    0.4848    0.4848
    1.0000    0.4545    0.4545
    1.0000    0.4242    0.4242
    1.0000    0.3939    0.3939
    1.0000    0.3636    0.3636
    1.0000    0.3333    0.3333
    1.0000    0.3030    0.3030
    1.0000    0.2727    0.2727
    1.0000    0.2424    0.2424
    1.0000    0.2121    0.2121
    1.0000    0.1818    0.1818
    1.0000    0.1515    0.1515
    1.0000    0.1212    0.1212
    1.0000    0.0909    0.0909
    1.0000    0.0606    0.0606
    1.0000    0.0303    0.0303
    1.0000         0         0];



tn = 32;

col = jet(tn);

dec_mem = [];

hist_mem1 = [];
hist_mem2 = [];

t1=29;
dt = 30;
th = (1:0.1:3);

for pi=3:3
    figure
    for ti=1:tn
        %file = ['G:\SHARED_PROJECTS\TDCs\20150216_cis\pos' num2digit(pi,2) '_tim' num2digit(ti,2) '.mat'];
        %file = ['G:\SHARED_PROJECTS\TDCs\2015-02-12_TDCs-Cisplatin-f8\dataslicing\pos' num2digit(pi,2) '_tim' num2digit(ti,2) '.mat'];
        file = ['C:\DATA\20150320_TDC_CIS_BK\dataslicing\pos' num2digit(pi,2) '_tim' num2digit(ti,2) '.mat'];
        load(file)
        
        
        pht = sumch(img,[3]);        
         %msk = repmat(medfilt2(pht(:,:,1),[5 5])>1.1*opthr(medfilt2(pht(:,:,1),[5 5])),[1 1 115 2]);
         msk = repmat(medfilt2(pht(:,:,1),[5 5])>50,[1 1 115 2]);
       dec = sumch(img.*msk,[1 2]);        
       
       %dec = sumch(img(130:190,80:160,:,:,:).*msk(130:190,80:160,:,:,:),[1 2]);        
       
        T1 = medfilt2(sumch(img(:,:,t1:t1+dt,1),[3]),[5 5]);
        T2 = medfilt2(sumch(img(:,:,t1+dt+1:t1+2*dt+1,1),[3]),[5 5]);
        RLD1 = (msk(:,:,1) .* (dt*0.1 ./ log(T1./(T2))));
        RLD1(isnan(RLD1))=0;
        T1 = medfilt2(sumch(img(:,:,t1:t1+dt,2),[3]),[5 5]);
        T2 = medfilt2(sumch(img(:,:,t1+dt+1:t1+2*dt+1,2),[3]),[5 5]);
        RLD2 = (msk(:,:,1) .* (dt*0.1 ./ log(T1./(T2))));
        RLD2(isnan(RLD2))=0;
        
        hist_mem1(ti,:)=histc(nonzeros(RLD1),th);
        hist_mem2(ti,:)=histc(nonzeros(RLD2),th);
        
        
        dec(:,1) = dec(:,1) - mean(dec(100:110,1));
        dec(:,2) = dec(:,2) - mean(dec(100:110,2));
        
        dec = dec ./repmat(max(dec),[size(dec,1) 1]);
        
        subplot(2,4,1)
        imagesc(pht(:,:,1))
        %imagesc(pht(130:190,80:160,1))
        set(gca,'clim',[1 1000])
        axis image
        axis off
        
        
        subplot(2,4,2)
        imagesc(pht(:,:,2))
        set(gca,'clim',[1 1000])                
        axis image
        axis off

        subplot(2,4,3)
        imagesc(RLD1)
        %imagesc(pht(130:190,80:160,1))
        set(gca,'clim',[1.3 1.9])
        axis image
        axis off   

        subplot(2,4,4)
        imagesc(RLD2)
        %imagesc(pht(130:190,80:160,1))
        set(gca,'clim',[1.4 2.0])
        axis image
        axis off           
        
        subplot(2,4,5)
        plot(dec(:,1),'color',col(ti,:))
        %set(gca,'yscale','log','ylim',[0.01 1],'xlim',[1 155])        
        hold on

        
        subplot(2,4,6)
        plot(dec(:,2),'color',col(ti,:))
        %plot(dec(:,1),dec(:,2),'color',col(ti,:))
        %set(gca,'yscale','log','ylim',[0.01 1],'xlim',[1 155])
        hold on
        
        
        
        subplot(2,4,7)
        plot(th,hist_mem1(ti,:)./sum(hist_mem1(ti,:)),'color',col(ti,:)) 
        %set(gca,'yscale','log','ylim',[0.01 1],'xlim',[1 155])        
        hold on  

        subplot(2,4,8)
        plot(th,hist_mem2(ti,:)./sum(hist_mem2(ti,:)),'color',col(ti,:)) 
        %set(gca,'yscale','log','ylim',[0.01 1],'xlim',[1 155])        
        hold on          
        
        drawnow
        
        colormap(LUT)
        
        dec_mem(pi,ti,:,:) = dec;
    end
    
end
%figure,plot(th,hist_mem2([1 17 20 23 32],:))        

%%
dec_mem2 = []
dim = 60;
figure
for pi=1:6
    for ti=1:tn
    
        dec1 = squeeze(dec_mem(pi,ti,:,1));
        dec2 = squeeze(dec_mem(pi,ti,:,2));
        
        idx1 = max(find(medfilt1(dec1,3)==max(medfilt1(dec1,3))))
        idx2 = max(find(medfilt1(dec2,3)==max(medfilt1(dec2,3))))
        
        dec1 = dec1(idx1:idx1+dim);
        dec2 = dec2(idx2:idx2+dim);
        
        dec1 = dec1/dec1(1);
        dec2 = dec2/dec2(1);
        
        subplot(2,1,1)
        plot(dec1,'color',col(ti,:))
        hold on
        subplot(2,1,2)
        plot(dec2,'color',col(ti,:))
        hold on
        
        dec_mem2(pi,ti,:,1) = dec1;
        dec_mem2(pi,ti,:,2) = dec2;
    end
    
end
 %%
 dec_av = squeeze(mean(dec_mem2,1));
 %dec_av = squeeze(dec_mem2(1,:,:,:));
 dec_st = squeeze(std(dec_mem2,[],1));
 
 time = (0:(dim))*0.082;
 
 zeroth_moment = sumch(dec_av,2);
 first_moment = sumch(dec_av.*repmat(time,[32 1 2]),2);
 
 rea = first_moment./zeroth_moment;
 rea = (rea-repmat(rea(1,:),[32 1]))./repmat((rea(end,:)-rea(1,:)),[32 1])
 
 figure
 for ti=1:32
     %plot((ti-1)*.5,rea(ti,1),'.'), hold on
     %plot((ti-1)*.5,rea(ti,2),'.g')
     plot(rea(ti,1),rea(ti,2),'.','color',col(ti,:))
     hold on
     
 end
 xlabel('Caspase9')
 ylabel('Caspase2')
 
 
 %%
time = (0:(dim))*0.082;
zeroth_moment = sumch(dec_mem2(:,:,:,:),3);
first_moment  = sumch(squeeze(dec_mem2(:,:,:,:)).*shiftdim(repmat(repmat(time,[32 1 2]),[1 1 1 6]),3),3);
rea = first_moment./zeroth_moment;
rea = (rea-repmat(rea(:,1,:),[1 32 1]))./repmat((rea(:,end,:)-rea(:,1,:)),[1 32 1]);

figure
plot(squeeze(mean(rea,1))+squeeze(std(rea,[],1)))
hold on
plot(squeeze(mean(rea,1)))
plot(squeeze(mean(rea,1))-squeeze(std(rea,[],1)))
         
 
 