function pipeId = elis_cs_open_fifo(tdcId)
    
    global cs_mode ELIS_CS_FIFO_EVENTS ELIS_CS_WORDLENGTH
  
    pipeId = elis_cs_check_err(calllib('scTDC1','sc_tdc_pipe_open2',tdcId,ELIS_CS_FIFO_EVENTS*ELIS_CS_WORDLENGTH(cs_mode),[],[]));

    display(['(FIFO) Pipe #' num2str(pipeId) ' opened successfully']);    
  
