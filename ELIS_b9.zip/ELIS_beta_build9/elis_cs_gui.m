% b5
% new file calling all other GUIs
% retain definitions for simpler control of the GUIs
% new waitbar GUI

global hgui

close all

%%
gui_prms.size = [10 500 200 400];
gui_prms.edge = 10; % min space from left
gui_prms.top  = 10; % min space from top
gui_prms.line_height = 25;
gui_prms.line_space  = 5;

elis_cs_gui_main;

%%
guia_prms.size = [220 500 200 400];
guia_prms.edge = gui_prms.edge; % min space from left
guia_prms.top  = gui_prms.top; % min space from top
guia_prms.line_space  = gui_prms.line_space;
guia_prms.line_height = 15;
guia_prms.col_width   = 80;
guia_prms.col_space   = 10;
guia_prms.edit_col    = 'white';

elis_cs_gui_acquire;
%%

guiw_prms.wb_x0   = 0.05;
guiw_prms.wb_y0   = 0.15;
guiw_prms.wb_x    = 0.9;
guiw_prms.wb_y    = 0.05;
guiw_prms.spacing = 0.3;
guiw_prms.font    = 6;
guiw.text_posy    = 2.6;
guiw_prms.size    = [10 423 410 75];

elis_cs_gui_waitbar;