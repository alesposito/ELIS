% check if a function returner an error code

function ret = elis_cs_check_err(err)

    if err<0
        error(['elis_cs> ' elis_cs_get_err_msg(err) ' error '  num2str(err)]);
    else
        ret = err;
    end