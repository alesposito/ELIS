%elis_cs_process_saved

% b5 preliminary testing code

files = {'c:/DATA/buffer_test_t001_000.mat','c:/DATA/buffer_test_t002_000.mat'};

fn = length(files);

for fi=1:fn
    % init process
    clear buf ptg chn utm
    
    
    %if isfield(hgui,'f_display')
    %    if ishandle(hgui.f_display)
    %        close hgui.f_display
    %    end
    %end
    
    load(files{fi})

    [utm, ptg, chn] = elis_cs_parse_data(buf, prms);
    
    elis_cs_histogram
    
    figure,plot((0:114)*img_prm.t_bin*img_prm.t_binning,sumch(img,[1 2 5])./repmat(max(sumch(img,[1 2 5])),[115 1]))   
end
    
%%


