%ret = elis_cs_get_err_msg(err)
%
% read error code from header

function ret = elis_cs_get_err_msg(err)
    
    fid = fopen('scTDC_error_codes.h','r');
    while ~feof(fid)
        line = fgetl(fid);
        line = strsplit(line);
        if length(line)==3
            if str2num(line{3})==err
                ret = line{2};
                return
            end
        end
        
    end
    