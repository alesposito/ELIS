
%% parse single block
[utm, ptg, chn] = elis_cs_parse_data(buf, prms);

%% slice single block

% reset initial pixel
ptg = ptg - min(ptg) + 1;            

% slice datastream  
[ptg, utm, chn, frame_idx] = elis_cs_slice_stream(ptg, utm, chn, img_prm, 'TDC-tags-on-channel');    

% bin/modulo operation on decays
utm = mod(utm, img_prm.t_mod);          % use modulto operation in order to cumulate (fold over) decays 
utm = ceil(utm/img_prm.t_binning)+1;    % binning time (reassign bin number)


