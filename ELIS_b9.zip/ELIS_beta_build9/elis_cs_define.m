function ret = elis_cs_define(type)
    
    switch lower(type)
        case 'sc_tdc_format'
            ret = libstruct(type);
            ret_fields = fieldnames(ret);
            for i=1:length(ret_fields)
                setfield(ret,ret_fields{i},1);    
            end
        otherwise
            error(['elis_cs> not supported data type (' type ')']);
    end