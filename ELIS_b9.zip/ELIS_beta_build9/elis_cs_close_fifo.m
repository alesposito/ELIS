function err = elis_cs_close_fifo(tdcId, pipeId)
        
    err = elis_cs_check_err(calllib('scTDC1','sc_pipe_close2',tdcId,pipeId));
    
    display(['(FIFO) Pipe #' num2str(pipeId) ' closed']);    
  
