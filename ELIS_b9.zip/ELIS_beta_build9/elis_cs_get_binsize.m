% get tdc binsize

function tdc_binsize = elis_cs_get_binsize(tdcId)

    [err tdc_binsize] =  calllib('scTDC1','sc_tdc_get_binsize2',tdcId,0);
    
    elis_cs_check_err(err);