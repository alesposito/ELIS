%%
n_pxl = 266

img2 = cat(1, zeros( n_pxl-mod(size(img,1),n_pxl),...
             size(img,2),...
             size(img,3)), img); %pad image
img2 = reshape(img2,[n_pxl size(img2,1)/n_pxl size(img2,2) size(img2,3)]);         


figure,
imagesc(sumch(img2,[3 4]))
set(gca,'clim',[0 150])
axis image
axis off
return