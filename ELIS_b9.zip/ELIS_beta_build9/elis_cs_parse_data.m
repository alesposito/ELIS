%% this function could be a private function later on, or masks made globals
% parse a FIFO buffer to return microtime (utm) pixel_tag (ptg) and channel
% (chn) information
% modulo is a structure defining modulo operation and related functions
% return modulo to update the pixel trimimming option
%
% --- build 4
% - continuing the work on flow control and FLIM mode
% - changes for speed optimization
% --- build 3
% - a lot of changes from build 2 aimed to support flow control and FLIM
%   modality. However, these changes were not succesful
%
% --- build 2
% - identify all time tags and parse correctly datastream depending
%   on TDC or FLIM modality
% - this function was doing a modulo operation in the build 1. This
%   functionality is now removed and has to be done during histogramming

function [utm, ptg, chn] = elis_cs_parse_data(mem, prms)

    global ELIS_CS_TIMETAG_START ELIS_CS_TIMETAG_STOP ELIS_CS_TIMETAG_MS ELIS_CS_TIMETAG_LINE ELIS_CS_TIMETAG_FRAME ELIS_CS_TIMETAG_COF ELIS_CS_TIMETAG_MAX 
    global ELIS_CS_CLKTAG_START  ELIS_CS_CLKTAG_STOP  ELIS_CS_CLKTAG_MS  ELIS_CS_CLKTAG_LINE  ELIS_CS_CLKTAG_FRAME 
    global ELIS_CS_DATATYPE
    global cs_mode cs_clock cs_mstag ELIS_CS_MODE_TDC ELIS_CS_MODE_FLIM
    
    % utm: microtimes
    % chn: channel
    % ptg: pixel tag

    ticparseId = tic;
    
    %%% INIT
    [idx_photons idx_mstick idx_start idx_stop idx_line idx_frame idx_cof] = deal([]) ;        
    [utm, ptg, chn] = deal(zeros(size(mem)));    
    chn             = chn*NaN;

    % @AE060115 somehow typecast does not work, but the following does    
    eval(['mem =' ELIS_CS_DATATYPE{cs_mode} '(mem);']);
    
    %%% create bit masks     
    utm_msk = sum(bitset(0,prms.time_data_offset + (1:prms.time_data_length) , ELIS_CS_DATATYPE{cs_mode}));
    chn_msk = sum(bitset(0,prms.channel_offset   + (1:prms.channel_length)   , ELIS_CS_DATATYPE{cs_mode}));    
    ptg_msk = sum(bitset(0,prms.ptg_offset       + (1:prms.ptg_length)       , ELIS_CS_DATATYPE{cs_mode}));    
    
    %%% identify tags
    % millisecond tags if ms tagging enabled
    if cs_mstag
        idx_mstick  = mem==ae_hex2dec(ELIS_CS_TIMETAG_MS{cs_mode}); 
    end    
    
    % valid photons tags
    idx_photons = mem <ae_hex2dec(ELIS_CS_TIMETAG_MAX{cs_mode});        
    
    % other tags
    if cs_clock
        idx_start   = mem==ae_hex2dec(ELIS_CS_TIMETAG_START{cs_mode}); % start tag
        idx_stop    = mem==ae_hex2dec(ELIS_CS_TIMETAG_STOP{cs_mode}); % stop tag
        idx_line    = mem==ae_hex2dec(ELIS_CS_TIMETAG_LINE{cs_mode}); % line tags
        idx_frame   = mem==ae_hex2dec(ELIS_CS_TIMETAG_FRAME{cs_mode}); % frame tags
        idx_cof     = mem==ae_hex2dec(ELIS_CS_TIMETAG_COF{cs_mode}); % sign counter overflow     
    end    
    
    %%% conditional exit if no valid photons are detected
    if isempty(idx_photons) | nnz(idx_photons)==0 | nnz(mem(idx_photons))==0        
        [utm, ptg, chn] = deal([]);        
        display('NO VALID DATA TO PARSE')
        return
    end
    
    %%% PARSIGN - MAIN BLOCK
    % assign values to data arrays, only for valid photon events
    utm(idx_photons) = bitand(mem(idx_photons), utm_msk, ELIS_CS_DATATYPE{cs_mode});
    ptg(idx_photons) = bitand(mem(idx_photons), ptg_msk, ELIS_CS_DATATYPE{cs_mode});
    chn(idx_photons) = bitand(mem(idx_photons), chn_msk, ELIS_CS_DATATYPE{cs_mode});

    chn = chn/bitset(0,prms.time_data_offset+1);
    ptg = ptg/bitset(0,prms.ptg_offset+1);
    chn = chn/bitset(0,prms.channel_offset+1);

    % transfer clock tags information to array chn (thi block can be commented out for speed)
    if nnz(idx_mstick)>0, chn(idx_mstick) = ELIS_CS_CLKTAG_MS;    end
    if nnz(idx_start)>0,  chn(idx_start)  = ELIS_CS_CLKTAG_START; end
    if nnz(idx_stop)>0,   chn(idx_stop)   = ELIS_CS_CLKTAG_STOP;  end
    if nnz(idx_line)>0,   chn(idx_line)   = ELIS_CS_CLKTAG_LINE;  end
    if nnz(idx_frame)>0,  chn(idx_frame)  = ELIS_CS_CLKTAG_FRAME; end

    % equalize format of data arrays between TDC and FLIM modalities
    switch cs_mode
        case ELIS_CS_MODE_FLIM
            % handle counter sign overflows
            if nnz(idx_cof)>0
                % @AE060115 unsure why +2 and not just +1!
                ptg(idx_cof) = 2^(prms.sign_counter_length)+2;                    
            end

            % cumulative sum on pixel tags
            ptg = cumsum(ptg);

            % remove cof events
            if ~isempty(idx_cof)                    
                ptg(idx_cof) = [];
                utm(idx_cof) = [];
                chn(idx_cof) = [];
            end                
        case ELIS_CS_MODE_TDC

            %if nnz(~idx_photons)>0
            %    ptg(~idx_photons) = ptg(~idx_photons-1);    
            %end

            % @AE03012015 the above is not strictly needed, but t
            % reassgign non photon tags to appropriate pixel tags
            % if this takes too much time comment out
            % need to check if two ~photons are adjecent how to fix it,
            % if needed
    end

    % erase all buffer values that remains unprocessed
    idx_unprocessed = isnan(chn);
    if nnz(idx_unprocessed)>0
       utm(idx_unprocessed) = [];
       ptg(idx_unprocessed) = [];
       chn(idx_unprocessed) = [];
    end

    toc(ticparseId)