%path_dll = 'C:\Program Files\Surface Concept\Time-to-Digital Converter\SDK\scTDC1\x64\';
path_dll = '.\';

%path_hdr = 'C:\Program Files\Surface Concept\Time-to-Digital Converter\SDK\scTDC1\headers\';
path_hdr = path_dll;
cd('.\')

file_dll = 'scTDC1.dll';
file_hdr = 'scTDC.h';


warning off

loadlibrary([path_dll file_dll],[path_hdr file_hdr],...
    'addheader',[path_hdr 'scTDC_types.h'],...
    'addheader',[path_hdr 'scTDC_error_codes.h'],...
    'includepath',path_hdr,...
    'mfilename', 'mHeader_tdc');

warning on

unloadlibrary('scTDC1')

