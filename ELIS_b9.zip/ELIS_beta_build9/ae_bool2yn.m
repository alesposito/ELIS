% convert boolean to YES/NO strings
% o = ae_bool2yn(bValue)
% o = ae_bool2yn(bValue, option)
% if option = 0, output is y/n (DEFAULT)
%             1, yes/no
%             2, YES/NO


function o = ae_bool2yn(bValue,varargin)

    if nargin==2
        option = varargin{1};
    else
        option = 0;
    end
    
    if bValue
        o = 'yes';
    else
        o = 'no';
    end
    
    switch option
        case 0
            o = o(1);
        case 1
            % no further operation needed
        case 2
            o = upper(o);
    end