% notes: 
% - add realtime hitogramming

% --- build 5
% - explicit allocation of arrays using max_events
% - auto-saving (dump2hd) functionality enabled
% - support GUI, including wait bars
% - support time outs
%
% --- build 4
% - modifications to avoid premature exit from FIFO reading
% - added a block to flush the FIFO at the end of the read
% - count_overflown and fifo_empty usage deprecated, replaced only by
%   timeouts: fifo reading cannot be longer than
%   ELIS_CS_TIMEOUT_FIFOREAD*acq_time
%   and gaps in data stream cannot be longer than
%   ELIS_CS_TIMEOUT_FIFOGAP (s)
%
% --- build 2
% - identify start/stop tags
% - returns all time tags




% type 'live' 'offline' 'no-hist'

% img = elis_cs_read_fifo(tdcId, fifo_events, max_events, type);
% [utm, ptg, chn, tag_idx] = elis_cs_read_fifo(tdcId, fifo_events, max_events, type);
% [utm, ptg, chn, tag_idx, img] = elis_cs_read_fifo(tdcId, fifo_events, max_events, type);


% @AE uncomment the following after debugging is completed. The call is already
% build 2
%function varargout = elis_cs_read_fifo(tdcId, max_events, type);

%    global ELIS_CS_FIFO_EVENTS ELIS_CS_WORDLENGTH ELIS_CS_MODE_TDC ELIS_CS_MODE_FLIM
%    global cs_mode


    type = 'offline';
    
    % parse inputs
    bHist = 1;
    switch lower(type)
        case 'live'
            bLive = 1;
        case 'offline'
            bLive = 0;        
        case 'no-hist'
            bHist = 0;
    end

    bVerbose = 1; % need to uncomment lines as well
    bPixelClockCheck = 1; % if two different FIFO reads contains the same pixel, it is likely that the scanner is not scanning.
    %% INITIALIZATIONS
    
    %  buffer allocations
    %  pre-allocation of the buffers will result faster performance of the
    %  FIFO read out
    
    % buffer array
    if exist('buf','var'); clear buf, end
    [dmb memory_usage]       = memory;
    memory_available   = memory_usage.PhysicalMemory.Available;
    memory_needed      = max_events*ELIS_CS_WORDLENGTH(cs_mode);
    
    if memory_needed<memory_available
        buf = zeros(1,max_events,ELIS_CS_DATATYPE{cs_mode});
    else
        error('buffer allocation interrupted to avoid possible OUT OF MEMORY. Reduce max_events.')
    end

    if ~exist('it','var') % identifier for time lapse
        it = 0; 
    end        
       
    % buffer array for single FIFO read
    buf_fifo  = zeros(ELIS_CS_FIFO_EVENTS,1,ELIS_CS_DATATYPE{cs_mode});    
    buf_fifo0  = zeros(ELIS_CS_FIFO_EVENTS,1,ELIS_CS_DATATYPE{cs_mode});    
    
    % other variables
    buf_tot        = 0; % total bytes read
    buf_overflow   = 0; % number of buffer overflows
    start_detected = 0; % START TAG detected
    stop_detected  = 0; % STOP TAG detected                                
    elapsed_time   = 0; % elapsed time from start read (needed for timeout)
    elapsed_gap    = 0; % elapsed time from previous individual FIFO read (needed for gap timeout)
    gap_flag       = 0; % previous FIFO read was empty       
    color_flag     = 0;
    
    % mask to retreve pixel tags
    ptg_msk = sum(bitset(0,prms.ptg_offset + (1:prms.ptg_length) , ELIS_CS_DATATYPE{cs_mode}));   
    ptg0 = -1; ptg1=-2;
    
    pipe_length    = ELIS_CS_FIFO_EVENTS*ELIS_CS_WORDLENGTH(cs_mode);   % FIFO data pipe length in bytes
    timeout_acq    = ELIS_CS_TIMEOUT_FIFOREAD*img_prm.acq_t/1000;            % acquisition timeout time
    timeout_gap    = ELIS_CS_TIMEOUT_FIFOGAP;                           % acquisition timeout time (gaps)        
    
    % structure containing information about the modulo operation
    % @AE this definition should be moved elsewhere
    modulo = struct('modulo', 455, ...     % length of a single decay in # of bins
                    'offset', 20,  ...     % bin offset to start
                    'binning', 4,  ...     % software binning for the decay
                    'trimptg', []);     % trimmed indexes from start
    % GUI           
    %if bLive
    %    hf_main = figure;
    %    ha_main = imagesc(zeros(256,256));
    %    axis image
    %    axis off
    %end
    
    ticreadId = tic;
    cs_waitbar_msg(hgui.fifo_txt,'CS FIFO BUFFER');
    cs_waitbar(hgui.fifo,buf_tot/max_events);   
    
    cs_waitbar_msg(hgui.elapsed_txt,['ACQUISITION TIME']);
    cs_waitbar(hgui.elapsed,0);
    
    drawnow
    
    % output
    if cs_autosave
        fileId = fopen([file_autosave '.txt'],'w');
    end
    
    %% FIFO READ
    
    while 1 % exit on timouts or matched coditions
   
        pause(.1)
        % read FIFO buffer       
        [buf_len, buf_fifo] = calllib('scTDC1','sc_tdc_pipe_read2',tdcId, buf_fifo0, pipe_length, 10);        

        
        if buf_len<0 % error in FIFO reading  
            
            serr = elis_cs_error_type(buf_len);
            display([mfilename '> no datastream detected... (' serr{1} ')'])                                    
                        
            % check gap timeout
            if buf_tot>10*1024 % if datastream has started
                if gap_flag % previous read was empty 
                    
                    elapsed_gap = toc(gap_ticId);
                    
                    if elapsed_gap>timeout_gap;
                        display(['break: timeout (long time gap between reads) - ' num2str(elapsed_gap) 'seconds']);
                        break
                    end 
                    
                else
                    gap_flag = 1;    % flag the read as a gap
                    gap_ticId = tic; % start timer                
                end
            end                
            
        else % receaving datatream    
            
            gap_flag = 0;            

            % print on screen if in Verbose modality
            if bVerbose
               display('receaving stream')
               display(['BUF TOT:' num2str(buf_tot+buf_len) 'BUF LEN:'  num2str(buf_len)])
            end

            % assign FIFO read to BUFFER data stream
            buf(:,buf_tot/ELIS_CS_WORDLENGTH(cs_mode)+(1:buf_len/ELIS_CS_WORDLENGTH(cs_mode))) = buf_fifo(1:buf_len/ELIS_CS_WORDLENGTH(cs_mode))';         
            buf_tot                        = buf_tot + buf_len;            
            
            % detect STOP TAG 
            stop_detected  = nnz(buf_fifo==ae_hex2dec(ELIS_CS_TIMETAG_STOP{cs_mode})) >0;
            if stop_detected
                display([mfilename '> Although data is straming, a STOP TAG was detected (exiting)'])
                break
            end
            
            % microscope not scanning condition 
            ptg1 = bitand(buf_fifo(1), ptg_msk, ELIS_CS_DATATYPE{cs_mode});
            if buf_tot>1024 & bPixelClockCheck% if there have been a data tream
                if ptg0==ptg1
                    display([mfilename '> Although data is straming, a pixel clock wa not detected (exiting)'])
                    break                    
                end
            end
            ptg0 = ptg1; % keep track of pixel tag 
            

        end
        
        % exit on time-out
        elapsed_time = toc(ticreadId);
        if elapsed_time>timeout_acq;
            display('break: timeout FIFO READ')
            break
        end 
        
        % buffer full (leave space for an extra read + 1KB statistics)
        if max_events-buf_tot-1024<pipe_length
            buf_overflow = buf_overflow +1;
            if cs_autosave % dump2file
                % save buffer to harddrive
                file_name = [file_autosave '_t' num2digit(it,3) '_' num2digit(buf_overflow,3) '.mat'];
                display(['Saving buffer to harddrive: ' file_name])
                if size(buf,2)>buf_tot
                    buf(buf_tot+1:end) = [];
                end
                save(file_name,'buf','-v7.3')
                % save information to textfile (used for auto read from secondary machine)
                fprintf(fileId,'%6.2f',buf_overflow);   
                % reset buffer
                buf(:)  = 0;
                buf_tot = 0;
            else
                display('break: buffer saturated, exiting')
                break            
            end
        end
        
        % update waitbar
        if mod(round(elapsed_time),2)<1
            cs_waitbar(hgui.fifo,buf_tot/max_events);      
            
            
            if toc(ticreadId)<=(img_prm.acq_t/1000)
                t_elapsed = toc(ticreadId)/(img_prm.acq_t/1000);
                cs_waitbar(hgui.elapsed,t_elapsed)
            else
                t_elapsed = 1-(toc(ticreadId)-img_prm.acq_t/1000)/(timeout_acq-img_prm.acq_t/1000);                
                cs_waitbar(hgui.elapsed,t_elapsed)
                cs_waitbar_msg(hgui.elapsed_txt,'TIMING OUT')
                if color_flag
                    cs_waitbar_col(hgui.elapsed,[1 0 0]);
                else
                    cs_waitbar_col(hgui.elapsed,[1 1 0]);
                end
                color_flag = ~color_flag;
            end
            
            drawnow
        end        
                
    end

    % interrupt acquisition if still running and flush the FIFO memory (b4)
    elis_cs_interrupt(tdcId)
    [buf_len, buf_fifo] = calllib('scTDC1','sc_tdc_pipe_read2',tdcId, buf_fifo, pipe_length, 10);  
    buf_len
    while buf_len>0
        buf(:,buf_tot/ELIS_CS_WORDLENGTH(cs_mode)+(1:buf_len/ELIS_CS_WORDLENGTH(cs_mode))) = buf_fifo(1:buf_len/ELIS_CS_WORDLENGTH(cs_mode))';         
        buf_tot = buf_tot + buf_len;
        warning(['A data stream was detected after an acquisition interrupt. One FIFO read added to data. (' num2str(buf_len) ' bytes)'])
        [buf_len, buf_fifo] = calllib('scTDC1','sc_tdc_pipe_read2',tdcId, buf_fifo, pipe_length, 10);                    
    end
    
    ticReadFIFOok = tic;

    buf = buf(1:buf_tot);
    
    if cs_autosave
        buf_overflow = buf_overflow +1;
        
        % save buffer to harddrive
        file_name = [file_autosave '_t' num2digit(it,3) '_' num2digit(buf_overflow,3) '.mat'];
        
        display(['Saving buffer to harddrive: ' file_name])
        
        if size(buf,2)>buf_tot/8
            buf(buf_tot/ELIS_CS_WORDLENGTH(cs_mode)+1:end) = [];
        end
        save(file_name,'buf','-v7.3')

        % save information to textfile (used for auto read from secondary machine)
        fprintf(fileId,'%6.2f',buf_overflow);   
        % reset buffer
        clear buf
        buf = zeros(1,max_events,ELIS_CS_DATATYPE{cs_mode});
        
        fclose(fileId)
    end

    
    toc(ticreadId);
    

    
    cs_waitbar(hgui.fifo,buf_tot/max_events);    
    cs_waitbar(hgui.elapsed,0)
    cs_waitbar_msg(hgui.elapsed_txt,'---')
    cs_waitbar_col(hgui.elapsed,[1 1 0]);


%     if nargout==1
%         varargout{1} = img;
%     else
%         varargout{1} = dat;
%         varargout{2} = tim;    
%         varargout{3} = chn;
%         varargout{4} = tag_idx;
% 
%         if ~strcmp(type,'no-hist')
%             varargout{5} = img;        
%         end
%     end