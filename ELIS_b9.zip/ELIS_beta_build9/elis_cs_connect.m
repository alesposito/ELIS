function tdcId = elis_cs_connect(gpx3ini)
    
    % Write a new ini file on harddrive
    elis_cs_writeini(gpx3ini); 
    % Connect device
    tdcId = elis_cs_check_err(calllib('scTDC1','sc_tdc_init_inifile',gpx3ini.filename));    
    
    display(['TDCs connected']); 