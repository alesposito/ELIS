function f = ae_memory

    [m1 m2] = memory;
    f = 1-m2.PhysicalMemory.Available/m2.PhysicalMemory.Total;