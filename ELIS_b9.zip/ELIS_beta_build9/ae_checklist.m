% check existance of files, folder, or variables, ...
% passed within a string
%
% ret = checklist(list)
% ret = checklist(list,delimiter)
%
% the default delimiter is ";"

function varargout = checklist(varargin)
    list = varargin{1};
    
    if nargin==2
        del = varargin{2};
    else
        del = ';';
    end


    for i=1:ae_picklist(list,[]);
        if exist(['' ae_picklist(list,i)],'file')==0
            if nargout==1
                varargout{1} = 0;
                return
            else
                error([mfilename '> missing element (' ae_picklist(list,i) ')']);
            end
        end
    end
    
   varargout{1} = 1;