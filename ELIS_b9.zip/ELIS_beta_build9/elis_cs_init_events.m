statusTimer = timer;
statusTimer.TimerFcn = 'cs_waitbar(hgui.memory,ae_memory)';
statusTimer.Period = 2;
statusTimer.StartDelay = 0;
statusTimer.TasksToExecute = Inf;
statusTimer.ExecutionMode = 'fixedSpacing';

