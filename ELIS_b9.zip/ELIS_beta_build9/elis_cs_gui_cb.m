% b3

function varargout = elis_cs_gui_cb(varargin)

    global hgui
    
    str_argin = '';
    for i=2:nargin
        str_argin = [str_argin 'varargin{' num2str(i) '},' ];
    end
    
    if nargout>0
        str_argout = '[';
        for i=1:nargout
            str_argout = [str_argout 'v' num2str(i) ',' ];
        end
        str_argout = [str_argout '] = '];
    else
        str_argout = '';
    end
    
    str_call = [str_argout varargin{1} '(' str_argin(1:end-1) ');'];   
    eval(str_call);
    
    if nargout>0        
        for i=1:nargout
            str_call = ['varargout{' num2str(i) '} = v' num2str(i) ';'];   
            eval(str_call);
        end        
    end

    
    % QUIT
    function cb_quit(tdcId)
        
        CNST_QUIT = 'QUIT';
        
        reply = questdlg('Are you sure you wish to quit ELIS.CS?','ELS.CS quitting...',CNST_QUIT,'CANCEL',CNST_QUIT);
        
        if strcmp(reply,CNST_QUIT)
        
            if tdcId>=0
                elis_cs_disconnect(tdcId);
                tdcId = [];
                unloadlibrary('scTDC1')
            end

            close all
            clc
            display(['ELIS_CS:TERMINATION FUNCTION EXECUTED (LIBRARY UNLOADED)']);
        end
        
    % toggle external trigger
    function b_trig = cb_tog_ext_trigger(b_trig) 
    
        global hgui
            
        b_trig = ~b_trig;
        
        set(hgui.tog_ext_trig,'value',b_trig);
        
        if b_trig
            display(['ELIS_CS extrernal trigger mode activated']);
        else
            display(['ELIS_CS extrernal trigger mode deactivated']);
        end
        
    % toggle FLIM/TDC modes
    function cb_tog_mode 
            
        global cs_mode ELIS_CS_MODE_TDC ELIS_CS_MODE_FLIM ELIS_CS_MODE_NAMES
        global hgui
        
        switch cs_mode
            case ELIS_CS_MODE_TDC
                cs_mode = ELIS_CS_MODE_FLIM;                
            case ELIS_CS_MODE_FLIM
                cs_mode = ELIS_CS_MODE_TDC;
        end
                
        set(hgui.tog_mode,'string',['mode (' ELIS_CS_MODE_NAMES{cs_mode} ')']);
        
        display(['ELIS_CS mode switched to ' ELIS_CS_MODE_NAMES{cs_mode}]);
             
    % connect/disconnect TDCs    
    function [tdcId gpx3ini tdc_binsize prms pipeId] = cb_tog_connect(tdcId, gpx3ini, cs_trigger, cs_mode, cs_mstag, cs_clock)
        
        global hgui 
        global ELIS_CS_MODE_TDC ELIS_CS_MODE_FLIM ELIS_CS_FILES_FIRMWARE ELIS_CS_FIRMWARE_TDC ELIS_CS_FIRMWARE_FLIM
        
        % GUI elements that should bedisable when connected
        h_enable  = [hgui.tog_ext_trig hgui.tog_mode];
        % GUI elements that should bedisable when dis-connected
        h_disable = [hgui.but_acquire hgui.but_single hgui.but_reparse hgui.but_rehist hgui.but_cont];
        
        if isempty(tdcId)
            % refresh firmware definition
            elis_cs_init_firmware;
            
            % connect
            tdcId = elis_cs_connect(gpx3ini);
            if tdcId>=0
                set(hgui.tog_connect,'string','disconnect');
                set(h_enable,'enable','off');
                set(h_disable,'enable','on');
            end     
            
            
            tdc_binsize = elis_cs_get_binsize(tdcId); % get bin size configured in the TDC
            prms        = elis_cs_get_format(tdcId);  % get data format
            pipeId      = elis_cs_open_fifo(tdcId);   % open pipe (FIFO)                      
            
        else
            
            elis_cs_disconnect(tdcId);
            tdcId = [];
            set(hgui.tog_connect,'string','connect');
            set(h_enable,'enable','on');        
            set(h_disable,'enable','off');
            [tdcId gpx3ini tdc_binsize prms pipeId] = deal([]);
        end
        