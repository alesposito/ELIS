%% ELIS Control Software BETA 1.2 (build-9)
%
% This is the first code to run Surface Concept TDCs
% All previous version are test files
%
% --- beta 1.2 (b9)
% - supporting start_devider and start_falling_edge options
% - clean-up for publication
%
% --- beta 1.1 (b7)
% - supporting gating of channels in TDC mode (gate by lie clock, record frame clock)
%
% --- beta 1.0 (b6)
% - this is a stable version used for the first experiments in the lab
% - minor bug corrected
% - DUMP2HD acquisition mode deprecated
% - real-time processing of multipoint timelapse implemented
%
% --- alpha 0.3 (b5)
% - improved GUI supporting a status bar
% - amended code for basic memory management and status bar usage
% - support continous acquisition and FIFO data stream saved directly to HD
% - support status timer and additional waiting bar for timing 
% - support mutli-point time lapse
% - early support of datastream slicing function with frame tagging on
%   chennel 4; this and other slicing functions are yet to be optimized
% - recoded histogramming function
%
% --- alpha 0.2 (b4)
% - improved speed of parsing
% - read fifo now is always stable in TDC mode after avoiding premature exiting of the block
% - added interrupt at the end of read fifo
% - added data slicing function to support multi point volumte acquisitions
%
% --- build-3
% - implementing FLIM modality (fast transfer) : suspended... resuming in
%   built-4
% - first GUI imlementation
%
% --- build-2
% - resolved confusion between TDC and FLIM mode
% - image parsing now handles non-pixel clocks, but needs further debugging
% - TDC modality fully funcioning and stable
% - definition and core functionality recoded for possible future public
%   releases
%
% --- build-1
% - all test code on m files have been converted into functions and
%   debugged
% - image hisogramming improved 

%% CONFIGURATION BLOCK - ELIS CS load libraries and generate GUI

% splash screen

splash = imread('elis.png','png');
hf = figure('toolbar','none','menubar','none','color','white','interruptible','off','WindowButtonDownFcn','close(hf);clear hf');
imshow(splash);
pause(2)
if exist('hf')
    close(hf);
end

elis_cs_init;               % call initialization file (@AE2014 check if function is possible)
elis_cs_init_firmware;      % make a function
elis_cs_init_img_prm;       % "
elis_cs_init_events;       
elis_cs_load_dll;           % load library (@AE2014 convert to a function) 
elis_cs_gui;

cs_status('GUI rendered')
cs_status_icon(ELIS_CS_STATUS_OK);
start(statusTimer)

