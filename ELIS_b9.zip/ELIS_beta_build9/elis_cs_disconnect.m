function err = elis_cs_disconnect(tdcId)       
    
    err = elis_cs_check_err(calllib('scTDC1','sc_tdc_deinit2',tdcId));    
    
    display(['TDC disconnected ( ' num2str(err) ' )']); 