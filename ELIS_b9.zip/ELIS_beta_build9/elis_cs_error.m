function elis_cs_error(msg)
    
    global ELIS_CS_PROMPT ELIS_CS_VERSION ELIS_CS_BUILD ELIS_CS_NAME
    
    error([ELIS_CS_PROMPT msg ' [' ELIS_CS_NAME '.v' ELIS_CS_VERSION ':b' ELIS_CS_BUILD ']'])
