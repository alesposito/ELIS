% ##
% The function num2digit convert an integer (or an integer stored in a string) to a string which length is filled with zeros
% to have the specified digits. num2digit is useful for loading and saving functions of multiple variables
%
% Usage: string_out = num2digit(in, n_digits)
% Version: 1.0 (2005-2008)
%
% Examples
%
% >> num2digit(1,3)
% ans =
%
% 001
%
% >> num2digit(1235,3)
%
% ans = 
%
% 1235
%
% >> num2digit('01',3)
%
% ans =
%
% 001
%
% See also: num2str, str2num

function s_o = num2digit(i_i, n_digits)
    s_o = num2str(i_i);
    for i = 1:n_digits-length(s_o)
        s_o = ['0' s_o];
    end
return