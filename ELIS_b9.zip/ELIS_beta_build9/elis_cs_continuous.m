% continuous acquire

1) continuous FIFO read