%% DEFINITION OF FIRMWARE STRUCTURE
% filename of the ".ini" file that will be used to initialize the TDCs

gpx3ini.filename    = 'elis.ini';

% set the correct firmware file that should be loaded
switch cs_mode
    
    case ELIS_CS_MODE_TDC
        gpx3ini.firmware    = ae_picklist(ELIS_CS_FILES_FIRMWARE,ELIS_CS_FIRMWARE_TDC);
        gpx3ini.nbytes      = 8;
        gpx3ini.time_tag    = 2;
        gpx3ini.det_type    = 'TDC';
        
    case ELIS_CS_MODE_FLIM
        gpx3ini.firmware    = ae_picklist(ELIS_CS_FILES_FIRMWARE,ELIS_CS_FIRMWARE_FLIM);
        gpx3ini.nbytes      = 4;
        gpx3ini.time_tag    = 0;
        gpx3ini.det_type    = 'FLIM';
    
    otherwise
        elis_cs_error([mfilename '> cs_mode: value (' num2str(cs_mode) ') not supported']);

end        
                
gpx3ini.ext_trigger = ae_bool2yn(cs_trigger,2); % wait for external trigger
gpx3ini.stat2flow   = ae_bool2yn(cs_clock,  2); % tag or not clock signals in the datastream 
gpx3ini.ms2flow     = ae_bool2yn(cs_mstag,  2); % add or not millisecond marker into datastream

gpx3ini.simulation  = 'NO';                     % simulation mode
gpx3ini.modulo      = 0;                        % modulo operation

gpx3ini.start_falling_edge = 'NO'; % supported from build 9 - used to be 'NO'
gpx3ini.start_devider = 10;         % supported from build 9 - used to be 32