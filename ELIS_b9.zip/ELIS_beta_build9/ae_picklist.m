% el = picklist(list, position)
% el = picklist(list, position, delimitator)
%
% [el, elements, N] = picklist(...)
% N = picklist(list,[])
% [N elements] = picklist(list,[])
%
% pick element "el" in position "position" from a string "list" containing
% a list of items delimited by the character "delimitator"
% the default delimitator is ";"
%
% elements return a cell array with the elements of the list
% N return the number of elements
% position can be set to [] if only elements and N should be returned

function varargout = picklist(varargin)
    list = varargin{1};
    pos  = varargin{2};
    
    if nargin==3
        del = varargin{3};
    else
        del = ';';
    end

    list = strtrim(strsplit(list,del));
    if ~isempty(pos)        
        el   = list{pos};
    end
    N    = length(list);
    
    if nargout==3
        varargout = {el,list,N};
        return
    end
    
    if isempty(pos)
       if nargout==1
           varargout{1} = N;
       else
           varargout{1} = N
           varargout{2} = list;
       end
    else
           varargout{1} = el;
    end
    
    if nargout==0
        varargout{1} = el;
    end
end