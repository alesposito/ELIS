if ~libisloaded('scTDC1')
    
    warning off

    loadlibrary([ELIS_CS_FILES_PATH ELIS_CS_FILES_MAINDLL],...
                ELIS_CS_FILES_PROTOTYPE,...
                'addheader',[ELIS_CS_FILES_PATH 'scTDC_types.h'],...
                'addheader',[ELIS_CS_FILES_PATH 'scTDC_error_codes.h'],...
                'includepath',ELIS_CS_FILES_PATH);

    warning on

    display([mfilename '> scTDC1 library loaded'])
    
else
    
    display([mfilename '> scTDC1 library was already loaded... skipping loading'])
    
end
    
    