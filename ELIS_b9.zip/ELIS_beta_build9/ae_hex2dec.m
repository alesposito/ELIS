function dec_num = ae_hex2dec(hex_num)
    
    if length(hex_num)>8
        dec_num = typecast(uint32(hex2dec([hex_num(9:end);hex_num(1:8)])),'uint64');
    else
        dec_num = uint32(hex2dec(hex_num));
    end