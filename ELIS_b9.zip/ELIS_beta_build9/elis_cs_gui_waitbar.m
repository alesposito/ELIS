% STATUS CONSTANT DEFINITIONS (MOVE TO INIT@)
ELIS_CS_STATUS_OK      = 1;
ELIS_CS_STATUS_WARNING = 2;
ELIS_CS_STATUS_ERROR   = 3;

% DRAW FIGURE
hgui.w_main = figure('Position',guiw_prms.size,...
                   'Name',[ELIS_CS_NAME ':initializing GUI'],...
                   'toolbar','none',...
                   'menubar','none',...
                   'numbertitle','off');

% create handler for status icon
warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');               
path_graphics = 'G:\SHARED_PROJECTS\TDCs\ELIS_alpha_build5\support_files\';
graphics_dot  = {'greenbut.png','yellowbut.png','redbut.png'};
guiw_jframe   = get(hgui.w_main,'javaframe');

% set position (function)               
posw = @(x)[guiw_prms.wb_x0
            guiw_prms.wb_y0+guiw_prms.spacing*(x-1)
            guiw_prms.wb_x
            guiw_prms.wb_y];

% status message (function)        
cs_status      = @(s)set(hgui.w_main,'Name',['status: ' s]);                         
% waitbar value (function)
cs_waitbar     = @(h,v)set(h,'xdata',[0 0 v v]);
% waitbar title (function)        
cs_waitbar_msg = @(h,s)set(h,'string',s);    
% waitbar title (function)        
cs_waitbar_col = @(h,c)set(h,'facecolor',c);    
% status icon (function)        
cs_status_icon = @(s)guiw_jframe.setFigureIcon(javax.swing.ImageIcon([path_graphics graphics_dot{s}]));





% initialize status
cs_status_icon(ELIS_CS_STATUS_WARNING)

guiw_line = 1; 

               axes('position',posw(guiw_line),...
                    'box','on',...
                    'xlim',[0 1],...
                    'XTickLabel','',...
                    'XTick',[],...
                    'YTick',[],...
                    'YTickLabel','');
                
hgui.elapsed_txt = text(0,guiw.text_posy,'---','fontsize',guiw_prms.font);                           
hgui.elapsed     = patch([0 0 0 0], [0 1 1 0],[1 1 0]);

guiw_line = guiw_line + 1; 

               axes('position',posw(guiw_line),...
                    'box','on',...
                    'xlim',[0 1],...
                    'XTickLabel','',...
                    'XTick',[],...
                    'YTick',[],...
                    'YTickLabel','');
                
hgui.fifo_txt = text(0,guiw.text_posy,'CS FIFO BUFFER','fontsize',guiw_prms.font);                           
hgui.fifo     = patch([0 0 0 0], [0 1 1 0],[1 0 0]);


guiw_line = guiw_line + 1; 

               axes('position',posw(guiw_line),...
                    'box','on',...
                    'xlim',[0 1],...
                    'XTickLabel','',...
                    'XTick',[],...
                    'YTick',[],...
                    'YTickLabel','');

hgui.memory_txt = text(0,guiw.text_posy,'PHYSICAL MEMORY USAGE','fontsize',guiw_prms.font);                                                                     
hgui.memory = patch([0 0 0 0], [0 1 1 0],[0 0 1]);

cs_waitbar(hgui.memory,ae_memory);              
if exist('buf','var'), cs_waitbar(hgui.fifo,nnz(buf)/max_events); end


