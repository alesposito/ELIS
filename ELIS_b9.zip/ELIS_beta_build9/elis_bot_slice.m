
%[file_name folder] = uigetfile('*.mat','Select one file of the datastack')

% next lines are for compatibility
folder_analysis = dest_name;
[folder file_name] = fileparts(buffer_name);
folder = [folder '\']


% base name
idx       = strfind(file_name,'_t');
idx       = idx(end); 
base_name = file_name(1:idx);

cd(folder)
mkdir(folder_analysis);

% load parameters
%display(['Loading parameter file (' base_name 'parameters.mat)...'])
%load('cisplatinTimelape_8-point_parameters.mat');
%img_prm.f = 16;
%img_prm.t = 32;

% load file names
files      = dir([folder '*t*_001.mat']);
files_done = {};
fn         = length(files);

%% GUI (@temporary)
max_format = 4096;
bot_bin    = 4;
bot_lut    = [1 0 0; 1 1 1; 0 1 0];

% img_prm.f = 7;
% img_prm.x=256;
% img_prm.y=256;
% img_prm.z=75;
% 
% img_prm.t=32;


bot_mosaic = zeros(floor(img_prm.f*img_prm.x/bot_bin),floor(img_prm.t*img_prm.y/bot_bin));
bot_loaded = zeros(img_prm.f,img_prm.t);
bot_sliced = zeros(img_prm.f,img_prm.t);

hbot.f_mosaic = figure;
hbot.a_mosaic = imagesc(bot_mosaic);
axis off
axis image
ylabel('position')
xlabel('time point')

hbot.f_status = figure;

subplot(3,1,1)
hbot.a_loaded = imagesc(bot_loaded);
axis image
ylabel('position')
xlabel('time point')
set(gca,'clim',[-1 1])

subplot(3,1,2)
hbot.a_sliced = imagesc(bot_sliced);
axis image
ylabel('position')
xlabel('time point')
set(gca,'clim',[-1 1])

subplot(3,1,3)
hbot.a_z = imagesc(zeros(1,img_prm.z));
axis image
xlabel('optical slice')
set(gca,'clim',[-1 1])

colormap(bot_lut)

movegui(hbot.f_status,'northeast')
movegui(hbot.f_mosaic,'northwest')

%%
% check if t0 = 1 or t0 = 0
file_name = files(1).name;    
if str2num(file_name(idx+2:idx+4))==0
    t0_offset = 1;
else
    t0_offset = 0;
end

for fi=1:fn
        
    try
        file_name = files(fi).name;       

        if ~ismember(files(fi).name,files_done)

            idx = strfind(file_name,'_t');
            ti = str2num(file_name(idx+2:idx+4)) + t0_offset;



            processed_positions = 0;
            block               = 0; % BLOCK: the buffer is saved in several different blocks onto HD
            z_block_shift       = 0; % sections already processed in the previous block


            current_frame = 0;
            current_position = 0;

            frame_idx = 0;
            buf0 = 0;
            buf  = 0;                

            while current_position<img_prm.f
                block = block + 1;


                if block>1
                    next_bloc_name = [file_name(1:max(strfind(file_name,'_'))) num2digit(block,3) '.mat'];    
                    if exist(next_bloc_name,'file')>0

                        file_name = next_bloc_name;

                        % keep unprocessed section of the datastream from
                        % previous block       
                        if frame_idx(1,1)~=-1
                            buf0 = buf(1,frame_idx(end,end)+1:end);
                        else
                            buf0 = buf;
                        end
                        %buf0_trans = length(buf0);

                        % load new block
                        display(['Loading ''' file_name '''']);
                        load(file_name)

    %                     img_prm.t=32
    %                     img_prm.f=8
    %                     

                        % merge with unprocessed data

                        buf = [buf0 buf];

                        %% this block is just a trick, need to understand what is wrong
                        buf(buf==0)=[];


                        clear buf0
                    else
                        bot_loaded(find(bot_loaded(:,ti)==0),ti)=-1
                        set(hbot.a_loaded,'cdata',bot_loaded);
                        drawnow
                        display('WARNING: LOST DATA BLOCK')
                        break 
                    end
                else       
                    display(['Loading ''' file_name '''']);
                    load([folder file_name]);
                end                        


                %% parse data stream
                display(['Parsing ''' file_name '''']);

                buf_lim = 10^8;
                bn      = ceil(size(buf,2)/buf_lim);
                if bn>1;
                    [utm, ptg, chn] = deal([]);    
                    for bi=1:bn
                        bi
                        buf_ini = (bi-1)*buf_lim+1;                    
                        buf_end = min([bi*buf_lim size(buf,2)]);

                        [tmp1, tmp2, tmp3] = elis_cs_parse_data(buf(buf_ini:buf_end), prms);

                        if ae_memory>0.8, error('STOPPED TO AVOID OUT OF MEMORY'), end
                        if prod(size(tmp1))~=0
                            utm = [utm tmp1];                        
                        end
                        clear tmp1

                        if ae_memory>0.8, error('STOPPED TO AVOID OUT OF MEMORY'), end
                        if prod(size(tmp2))~=0
                            ptg = [ptg tmp2];
                        end
                        clear tmp2

                        if ae_memory>0.8, error('STOPPED TO AVOID OUT OF MEMORY'), end
                        if prod(size(tmp3))~=0
                            chn = [chn tmp3];
                        end
                        clear tmp3
                    end
                else
                    [utm, ptg, chn] = elis_cs_parse_data(buf, prms);
                end

                %% slice single block
                display(['Slicing ''' file_name '''']);
                % reset initial pixel
                %if ~isempty(buf0_trans) % restablish continuty of pixel number at boundary of data blocks
                %    % WARNING
                %    ptg0_trans = ptg(buf0_trans)
                %    ptg_trans  = ptg(buf0_trans+1)
                %    ptg(buf0_trans+1:end) = ptg - ptg_trans + ptg0_trans;
                %end
                ptg = ptg - min(ptg) + 1;            

                % slice datastream  
                [ptg, utm, chn, frame_idx] = elis_cs_slice_stream(ptg, utm, chn, img_prm, 'TDC-tags-on-channel');    
                %[ptg, utm, chn, frame_idx] = elis_cs_slice_stream(ptg, utm, chn, img_prm, 'TDC-tags-on-channel2');    % gated version
               if frame_idx(1,1) ~=-1
                    % bin/modulo operation on decays
                    utm = mod(utm, img_prm.t_mod);          % use modulto operation in order to cumulate (fold over) decays 
                    utm = ceil(utm/img_prm.t_binning)+1;    % binning time (reassign bin number)

                    %% histogram single block 
                    tot_frm_blc = length(frame_idx);                % total number of frames within this data block
                    tot_frm_img = img_prm.z;                        % total number of frames per image        
                    tot_pos_blc = round(tot_frm_blc/tot_frm_img);   % estimated number of fields of view within this block


                    %%
                    display(['Histogramming ''' file_name '''']);
                    bot_loaded(1:tot_pos_blc,ti) = 1;
                    set(hbot.a_loaded,'cdata',bot_loaded);
                    drawnow

                    %%
                    for zi=1:tot_frm_blc

                        % start of the z-stack
                        if mod(current_frame,img_prm.z)==0
                            current_position = current_position + 1;
                            display(['Processing FoV ' num2str(current_position) ' of ' num2str(img_prm.f) ]);

                            % initialize single image
                            switch mode_3d
                                case 'extended_focus'
                                    img = zeros([img_prm.x img_prm.y max(utm) img_prm.n_ch]);
                                case 'downsampled'
                                    img = zeros([img_prm.x img_prm.y max(utm) img_prm.n_ch img_prm.z]);
                            end

                            tmp = [];
                        end

                        current_frame = current_frame + 1;

                        si = mod(current_frame-1,img_prm.z)+1;

                        set(hbot.a_z,'cdata',circshift([1 zeros(1,img_prm.z-1)],[0 si-1]));
                        drawnow

                        display(['Processing frame ' num2str(si) ' of ' num2str(tot_frm_img) ]);

                        % extract indivual frame from data stream
                        ptg3 = ptg(frame_idx(zi,1):frame_idx(zi,2));
                        utm3 = utm(frame_idx(zi,1):frame_idx(zi,2));
                        chn3 = chn(frame_idx(zi,1):frame_idx(zi,2));

                        %run some diagnostics on ptg3 
                        % remove strange initial pixels
                        [a b]=sort(ptg3(1:20));
                        if b(1)~=1
                            ptg3(1:b(1)) = [];
                            utm3(1:b(1)) = [];
                            chn3(1:b(1)) = [];                       
                        end


                        % reset initial pixel
                        ptg3 = ptg3 - min(ptg3) +1;

                        % trim excess pixels (if slicing correct these will be just frame/stack retracing pixels)                    
                        idx = (ptg3<max(ptg3)-(img_prm.x+img_prm.rx)*img_prm.y+1) | chn3>2;

                        if ~isempty(idx)
                            ptg3(idx) = [];
                            utm3(idx) = [];
                            chn3(idx) = [];

                            ptg3 = ptg3- min(ptg3) +1; 
                        end                     

                        % histrogam individual frame, pad with zeros if missing pixels and
                        % reshape to image format
                        tmp = accumarray({ptg3,utm3,chn3+1},1);
                        if size(tmp,1)<(img_prm.x+img_prm.rx)*img_prm.y
                            tmp = cat(1,tmp,zeros((img_prm.x+img_prm.rx)*img_prm.y-size(tmp,1),size(tmp,2),size(tmp,3)));             
                        end        
                        tmp = reshape(tmp,[img_prm.x+img_prm.rx img_prm.y size(tmp,2) size(tmp,3)]);

                        % trim line retracing pixels
                        %if bResynchFrameHeurstic
                            x_proj  = sumch(tmp(:,:,:,:),[2 3 4]);    
                            x_shift = find(x_proj==max(x_proj));         
                            tmp     = circshift(tmp,[-x_shift 0 0 0]);
                        %end            

                        switch mode_3d
                            case 'extended_focus'
                                img = img + cat(4,tmp(1:img_prm.x,:,:,:),zeros([img_prm.x size(tmp,2) size(tmp,3) (size(img,4)-size(tmp,4))]));
                            case 'downsampled'
                                img(:,:,:,:,si) = cat(4,tmp(1:img_prm.x,:,:,:),zeros([img_prm.x size(tmp,2) size(tmp,3) (size(img,4)-size(tmp,4))]));
                        end

                        if si==tot_frm_img
                            switch mode_3d
                                case 'extended_focus'
                                    % no action
                                case 'downsampled'
                                    % downsampling                        
                                    n_down = 5; % downsamplig factor
                                    % pad z dir
                                    if mod(img_prm.z,n_down)>0
                                        img = cat(5,img,zeros([img_prm.x img_prm.y max(utm) img_prm.n_ch  mod(img_prm.z,n_down)]));
                                    end
                                    img = sumch(reshape(img,[img_prm.x img_prm.y max(utm) img_prm.n_ch  n_down size(img,5)/n_down]),5);

                                    img3d = sumch(img,[3]);
                                    img   = sumch(img,5); % extended focus
                            end                        

                            decays   = sumch(img,[1 2]);
                            decays   = decays./repmat(max(decays),[size(decays,1) 1]);
                            dpeaks   = mod(find(decays==1),size(decays,1));
                            t_shifts = dpeaks-min(dpeaks);

                            t_shifts = cat(1,t_shifts,zeros(size(img,4)-size(t_shifts,1)))

                            for i_ch=1:img_prm.n_ch
                                img(:,:,:,i_ch) = circshift(img(:,:,:,i_ch),-[0 0 t_shifts(i_ch) 0 0]);
                            end

                            % save file
                            save_name = [folder_analysis '/pos' num2digit(current_position,2) '_tim' num2digit(ti,2) '.mat'];
                            display(['Saving: ' save_name])
                            save(save_name,'img')

                            switch mode_3d
                                case 'extended_focus'
                                    % no action
                                case 'downsampled'
                                    for cci=1:size(img3d,3)
                                        for zzi=1:size(img3d,4)
                                            imwrite(uint8(256*squeeze(img3d(:,:,cci,zzi))/512),[folder_analysis '/pos' num2digit(current_position,2) '_tim' num2digit(ti,2) '_c' num2digit(cci,2) '_z' num2digit(zzi,2) '.tif'])
                                        end
                                    end
                            end                        



                            bot_sliced(current_position,ti) = 1;
                            set(hbot.a_sliced,'cdata',bot_sliced);
                            drawnow
                        end

                    end

                end
            end
            files_done{length(files_done)+1} = file_name;
        end
        
    catch
        warning('NOT DONE')
    end
            
            
end
            
            
            
            
            
            

  


                    
                                                       
            


