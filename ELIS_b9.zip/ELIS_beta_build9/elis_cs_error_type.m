function str = elis_cs_error_type(err)

    global ELIS_CS_ERROR_LUT ELIS_CS_ERROR_TABLE
       
    str = (ELIS_CS_ERROR_TABLE(find(ELIS_CS_ERROR_LUT==err)));
    
    if nargout ==0
        display(str);
    end