%% DISPLAY SECTION - THIS WILL HAVE TO BE MOVED AND RECODED
bRGB =1;
bLT  = 0;

bDisplayFilt = 0;
MEDFILTDISP = [3 3];
MEDFILTSCAL = [2 2];
SUMFILTRLD = [3 3];

if bLT % initialize RLD algorithm
    
    img = double(img);                 % convert to double to support division
    d0 = dpeaks(t_shifts==0)+1;        % start of decay for RLD algorithm (bin #)
    
    % estimate the 95th percentile of the decay
    % and exclude empty bins accordingly then
    % define gate width
    cumsum_decay = cumsum(sumch(decays(d0:end,:),2));
    cumsum_decay = cumsum_decay./max(cumsum_decay);
    dt = floor(max(find(cumsum_decay<=0.95))/2);
    
end

n_frm = size(img,5);

hgui.f_display = figure;

for i=1:img_prm.n_ch     
    for j=1:n_frm
        
        
        dc  = sumch(img(:,:,:,i,j),3);        
        
        subplot(img_prm.n_ch+bRGB+bLT,n_frm,j+(i-1)*n_frm)

        if bDisplayFilt
            dc = medfilt2(dc,MEDFILTDISP);
        end
        scmax =  max([1; nonzeros(medfilt2(dc,MEDFILTSCAL))]);        
        
        imagesc(dc')
        
        set(gca,'clim',[0 scmax])
        axis image
        axis off
        colorbar

        if bRGB & i==img_prm.n_ch
            subplot(img_prm.n_ch+bRGB+bLT,n_frm,j+(img_prm.n_ch)*n_frm)
            imshow(cat(3,sumch(img(:,:,:,:,j),3),zeros(size(img,1),size(img,2),3-img_prm.n_ch))/(1.5*scmax));
        end
        
        if bLT & i==1
            subplot(img_prm.n_ch+bRGB+bLT,n_frm,j+(img_prm.n_ch+bLT+bRGB-1)*n_frm)
            
            T1 = imfilter(sumch(img(:,:,d0+(dt+1:2*dt+1),i,j),3),ones(SUMFILTRLD));
            T2 = imfilter(sumch(img(:,:,d0+(0:dt),     i,j),3),ones(SUMFILTRLD));
            
            T = -(((dt/size(img,3))*12.5/2))*log(T1./T2);
            T(isinf(T))=0;
            T(isnan(T))=0;
            T = T.*(dc>100);
            imagesc(T)
            mean(nonzeros(T))
            
            set(gca,'clim',[0 max([nonzeros(medfilt2(T,[2 2])); 1])])
            axis image
            axis off
            colorbar            
        end        
    end
end
