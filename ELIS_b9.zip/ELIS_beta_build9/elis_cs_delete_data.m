function [ttg2, utm2, chn2, tag_idx] = elis_cs_delete_data(ttg2, utm2, chn2, tag_idx, p0, p1);

        % delete data block
        ttg2(p0:p1)  = []; 
        utm2(p0:p1)  = []; 
        chn2(p0:p1)  = [];
        
        % reset number of initial pixel
        ttg2         = ttg2 - min(ttg2) +1;
        
        % reset tag indexing
        idx_names = fieldnames(tag_idx);
        for i=1:length(idx_names)
            setfield(tag_idx,idx_names{i},getfield(tag_idx,idx_names{i})-p1+p0+1)
        end
        % @@@@@AE IMPORTAND.... THE ABOVE WOULD NOT WORK
        % NEED TO REPLACE ONLY THE TAGS THAT ARE AFTER P0
        % AND NEED TO BE TOLERANT TO EMPTY ARRAYS