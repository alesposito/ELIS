% build-2 update
% improve definitions
% avoid confsion between TDC and FLIM modalities

%% FLUSH MEMORY
if exist('tdcId','var') %@AE010115 improve restart
    clearvars -except tdcId
else
    clear all
end

close all
clc

%% DEFINITION OF CONSTANTS AND GLOBALS

% VERSION
global ELIS_CS_NAME ELIS_CS_VERSION ELIS_CS_PROMPT ELIS_CS_BUILD
ELIS_CS_VERSION = 'beta 1.2';
ELIS_CS_BUILD   = '9';
ELIS_CS_PROMPT  = '>';
ELIS_CS_NAME    =  'ELIS.CS';

% TDCs can operate at 30MHz or 60MHz maximum transfer speed on USB3.
% In the two modalities image histogramming operate differently, therefore,
% ELIS CS needs to be aware of which modality it is using.
global ELIS_CS_MODE_TDC ELIS_CS_MODE_FLIM ELIS_CS_MODE_NAMES
ELIS_CS_MODE_NAMES  = {'TDC','FLIM'};
ELIS_CS_MODE_TDC    = 1;
ELIS_CS_MODE_FLIM   = 2;

% FIRMWARE MODALITY (select the appropriate firmware defined in the FILES_FIRMWARE list)
global ELIS_CS_FIRMWARE_FLIM ELIS_CS_FIRMWARE_TDC ELIS_CS_FILES_FIRMWARE
ELIS_CS_FIRMWARE_FLIM = 2;
ELIS_CS_FIRMWARE_TDC  = 1;

% ESSENTIAL FILES DEFINITION (these files are vendor specific)
ELIS_CS_FILES_FIRMWARE  = 'sctdc_ex301.bit; sctdc_301_flim.bit';
ELIS_CS_FILES_LIBRARIES = 'msvcp100.dll; msvcr100.dll; pthreadVC2.dll; scDevice6DLL.dll; scDeviceClass60.dll; scTDC1.dll';
ELIS_CS_FILES_HEADERS   = 'scTDC.h; scTDC_error_codes.h; scTDC_types.h';
ELIS_CS_FILES_MAINDLL   = 'scTDC1.dll';
ELIS_CS_FILES_PATH      = './';
ELIS_CS_FILES_PROTOTYPE = @mHeader_tdc_v3;

% TIME TAGS DEFINITIONS
global ELIS_CS_TIMETAG_START ELIS_CS_TIMETAG_STOP ELIS_CS_TIMETAG_MS ELIS_CS_TIMETAG_LINE ELIS_CS_TIMETAG_FRAME ELIS_CS_TIMETAG_COF ELIS_CS_TIMETAG_MAX
ELIS_CS_TIMETAG_START = {'FFFFFFFFFFFFFFFC','FFFFFFFC'}; % start of acquision (64 bit , 32 bit)
ELIS_CS_TIMETAG_STOP  = {'FFFFFFFFFFFFFFFB','FFFFFFFB'}; % end of acquisition (64 bit , 32 bit)
ELIS_CS_TIMETAG_MS    = {'FFFFFFFFFFFFFFFA','FFFFFFFA'}; % millisecond tag (64 bit , 32 bit)
ELIS_CS_TIMETAG_LINE  = {'FFFFFFFFFFFFFFF7','FFFFFFF7'}; % end of line (64 bit , 32 bit)
ELIS_CS_TIMETAG_FRAME = {'FFFFFFFFFFFFFFFD','FFFFFFFD'}; % end of frame (64 bit , 32 bit)
ELIS_CS_TIMETAG_COF   = {'FFFFFFFFFFFFFFF8','FFFFFFF8'}; % sign counter overflow (64 bit , 32 bit)
ELIS_CS_TIMETAG_MAX   = {'FFFFFFFFFFFFFFF0','FFFFFFF0'}; % max permissible number for photon event (64 bit , 32 bit)

global ELIS_CS_CLKTAG_START  ELIS_CS_CLKTAG_STOP  ELIS_CS_CLKTAG_MS  ELIS_CS_CLKTAG_LINE  ELIS_CS_CLKTAG_FRAME  ELIS_CS_CLKTAG_COF
ELIS_CS_CLKTAG_START = -1;
ELIS_CS_CLKTAG_COF   = -2;
ELIS_CS_CLKTAG_LINE  = -3;
ELIS_CS_CLKTAG_FRAME = -4;
ELIS_CS_CLKTAG_STOP  = -5;
ELIS_CS_CLKTAG_MS    = -6;

% MEMORY PIPE CONFIGURATION
global ELIS_CS_FIFO_EVENTS ELIS_CS_WORDLENGTH ELIS_CS_DATATYPE
ELIS_CS_WORDLENGTH  = [8 4];                % word length in bytes for 64 bits (TDC) and 32 bits (FLIM) operation
ELIS_CS_DATATYPE    = {'uint64','uint32'};  % data type
ELIS_CS_FIFO_EVENTS = 10000*1024;            % FIFO dimension in number of events



% TDC ERROR CODES

ELIS_CS_TDC_ERR_DEFAULT                 = -1; 
ELIS_CS_TDC_ERR_INIFILE                 = -2; 
ELIS_CS_TDC_ERR_TDCOPEN                 = -3; 
ELIS_CS_TDC_ERR_NOMEM                   = -4; 
ELIS_CS_TDC_ERR_SERIAL                  = -5; 
ELIS_CS_TDC_ERR_TDCOPEN2                = -6; 
ELIS_CS_TDC_ERR_PARAMETER               = -7; 
ELIS_CS_TDC_ERR_SMALLBUFFER             = -8; 
ELIS_CS_TDC_ERR_BADCONFI                = -9; 
ELIS_CS_TDC_ERR_NOTINIT                 = -10; 
ELIS_CS_TDC_ERR_NOTRDY                  = -11; 
ELIS_CS_TDC_ERR_DEVCLS_LD               = -12; 
ELIS_CS_TDC_ERR_DEVCLS_VER              = -13; 
ELIS_CS_TDC_ERR_DEVCLS_INIT             = -14; 
ELIS_CS_TDC_ERR_FPGA_INIT               = -15; 
ELIS_CS_TDC_ERR_ALRDYINIT               = -16; 
ELIS_CS_TDC_ERR_TIMEOUT                 = -17; 
ELIS_CS_TDC_ERR_NOSIMFILE               = -18; 
ELIS_CS_TDC_ERR_GPX_RST                 = -21; 
ELIS_CS_TDC_ERR_GPX_PLL_NLOCK           = -22; 
ELIS_CS_TDC_ERR_USB_COMM                = -30; 
ELIS_CS_TDC_ERR_BIN_SET                 = -41; 
ELIS_CS_TDC_ERR_ROI_SET                 = -42; 
ELIS_CS_TDC_ERR_FMT_SET                 = -43; 
ELIS_CS_TDC_ERR_FMT_UNSUPPORT           = -44; 
ELIS_CS_TDC_ERR_ROI_BAD                 = -45; 
ELIS_CS_TDC_ERR_ROI_TOOBIG              = -46; 
ELIS_CS_TDC_ERR_BUFSIZE                 = -47; 
ELIS_CS_TDC_ERR_GPX_FMT_UNSUPPORT       = -48; 
ELIS_CS_TDC_ERR_GPX_FMT_SET             = -49; 
ELIS_CS_TDC_ERR_FMT_NDEF                = -50; 
ELIS_CS_TDC_ERR_FIFO_ADDR_SET           = -60; 
ELIS_CS_TDC_ERR_MODE_SET                = -61; 
ELIS_CS_TDC_ERR_START_FAIL              = -62; 
ELIS_CS_TDC_ERR_TIMER_SET               = -63; 
ELIS_CS_TDC_ERR_TIMER_EX_SET            = -64; 
ELIS_CS_TDC_ERR_STRT_FREQ_DIV_SET       = -65; 
ELIS_CS_TDC_ERR_STRT_FREQ_PERIOD_SET    = -66; 
ELIS_CS_TDC_ERR_TWI_NO_MODULE           = -70; 
ELIS_CS_TDC_ERR_TWI_FAIL                = -71; 
ELIS_CS_TDC_ERR_TWI_NACK                = -72; 
ELIS_CS_TDC_ERR_POT_NO                  = -73; 
ELIS_CS_TDC_ERR_POT_SET                 = -74; 
ELIS_CS_TDC_ERR_FLIM_PARM_SET           = -80; 
ELIS_CS_TDC_ERR_OPEN_LINE_CORR_FILE     = -81; 
ELIS_CS_TDC_ERR_WRONG_LINE_CORR_FILE    = -82; 
ELIS_CS_TDC_ERR_CONNLOST                = -90; 
ELIS_CS_TDC_ERR_SYSTEM                  = -1000; 
ELIS_CS_TDC_ERR_NOT_IMPL                = -9000; 
ELIS_CS_TDC_INFO_MEAS_COMPLETE          = 1; 
ELIS_CS_TDC_INFO_USER_INTERRUPT         = 2; 
ELIS_CS_TDC_INFO_BUFFER_FULL            = 3; 

global ELIS_CS_ERROR_LUT ELIS_CS_ERROR_TABLE

ELIS_CS_ERROR_LUT   = -[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 21 22 30 41 42 43 44 45 46 47 48 49 50 60 61 62 63 64 65 66 70 71 72 73 74 80 81 82 90 1000 9000 -1 -2 -3];
ELIS_CS_ERROR_TABLE = {'TDC_ERR_DEFAULT','TDC_ERR_INIFILE','TDC_ERR_TDCOPEN','TDC_ERR_NOMEM','TDC_ERR_SERIAL','TDC_ERR_TDCOPEN2','TDC_ERR_PARAMETER','TDC_ERR_SMALLBUFFER','TDC_ERR_BADCONFI','TDC_ERR_NOTINIT', ...
                       'TDC_ERR_NOTRDY','TDC_ERR_DEVCLS_LD','TDC_ERR_DEVCLS_VER','TDC_ERR_DEVCLS_INIT','TDC_ERR_FPGA_INIT','TDC_ERR_ALRDYINIT','TDC_ERR_TIMEOUT','TDC_ERR_NOSIMFILE','TDC_ERR_GPX_RST','TDC_ERR_GPX_PLL_NLOCK',...
                       'TDC_ERR_USB_COMM','TDC_ERR_BIN_SET','TDC_ERR_ROI_SET','TDC_ERR_FMT_SET','TDC_ERR_FMT_UNSUPPORT','TDC_ERR_ROI_BAD','TDC_ERR_ROI_TOOBIG','TDC_ERR_BUFSIZE','TDC_ERR_GPX_FMT_UNSUPPORT','TDC_ERR_GPX_FMT_SET',...
                       'TDC_ERR_FMT_NDEF','TDC_ERR_FIFO_ADDR_SET','TDC_ERR_MODE_SET','TDC_ERR_START_FAIL','TDC_ERR_TIMER_SET','TDC_ERR_TIMER_EX_SET','TDC_ERR_STRT_FREQ_DIV_SET','TDC_ERR_STRT_FREQ_PERIOD_SET',...
                       'TDC_ERR_TWI_NO_MODULE','TDC_ERR_TWI_FAIL','TDC_ERR_TWI_NACK','TDC_ERR_POT_NO','TDC_ERR_POT_SET','TDC_ERR_FLIM_PARM_SET','TDC_ERR_OPEN_LINE_CORR_FILE','TDC_ERR_WRONG_LINE_CORR_FILE',...
                       'TDC_ERR_CONNLOST','TDC_ERR_SYSTEM','TDC_ERR_NOT_IMPL','TDC_INFO_MEAS_COMPLETE','TDC_INFO_USER_INTERRUPT','TDC_INFO_BUFFER_FULL'};     
% @AE050115 WARNING: I HAVE TWO ERROR FUNCTION CURRENTL (CHECK ERR AND GET ERR MSG, DO INTEGRATE THEM)
                   

ELIS_CS_TIMEOUT_FIFOREAD = 4;%2;   % time out of total FIFO read time (folds of acq_time) 
ELIS_CS_TIMEOUT_FIFOGAP  = 1.5; % time out in gaps within datastream (second)

%% SET VALUES @AE010115, this may be replaced by GUI of file in future releases
global cs_mode cs_mstag cs_clock
%cs_mode = ELIS_CS_MODE_TDC;
cs_mode = ELIS_CS_MODE_FLIM;

cs_trigger  = 1;             % wait for trigger to start [0/1]
cs_mstag    = 0;             % tag millisecond markers in data stream
cs_clock    = 1;             % tag clock signals in data stream
cs_chn      = [1 1 1 0];     % switches on/off parsing of channels
cs_autosave = 1;             % autosave buffer when is full

file_autosave = 'c:/DATA/buffer'

tdcId  = [];
pipeId = [];


%% CHECK FOLDER AND FILES
path_main      = fileparts(which(mfilename));
cd(path_main)

if exist(ELIS_CS_FILES_PATH,'dir')~=7
    error('Library folders not found')
end

addpath('.');
addpath(ELIS_CS_FILES_PATH);

% check firmwire files
ae_checklist(ELIS_CS_FILES_FIRMWARE);
ae_checklist(ELIS_CS_FILES_LIBRARIES);
ae_checklist(ELIS_CS_FILES_HEADERS);
ae_checklist(ELIS_CS_FILES_MAINDLL);
ae_checklist(ELIS_CS_FILES_FIRMWARE);
ae_checklist([getfield(functions(ELIS_CS_FILES_PROTOTYPE),'function') '.m']);