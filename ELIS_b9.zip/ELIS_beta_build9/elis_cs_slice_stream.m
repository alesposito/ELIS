% --- b7
% support CFD gating

% --- b6
% - improvements of speed and memory usage (necessary for multi point time lapse)

% --- b5
% this slicing function does not work robustrly. In b5, the heuristic for
% slicing is removed and replaced, at least temporarily, but the frame tag
% grabbed by the fourth channel of the TDC (bFrameOnChannel)
%
% --- b4
% analyze a data stream to extract individual frames if no frame tag is
% detected (for instance, in TDC mode)
% 1) remove trailing and initial data that does not belog to images
% 2) return the cleaned datastream and the index to the beginning of frames
% based on empyrical rules, need to check for generality

function [ptg, utm, chn, frame_index] = elis_cs_slice_stream(ptg, utm, chn, img_prm, slice_type)

    global ELIS_CS_CLKTAG_START  ELIS_CS_CLKTAG_STOP  ELIS_CS_CLKTAG_MS  ELIS_CS_CLKTAG_LINE  ELIS_CS_CLKTAG_FRAME 

    % init
    bDebug = 0;
    
    n_pxl = img_prm.x+img_prm.rx;
    n_lin = img_prm.y;
    
    supported_types = {'FLIM',...               % line and frame tags are stored in chn input as negative values
                       'trim',...               % only trime trailing and haders pixels
                       'TDC-single',...         % single image (possible multiple frame
                       'TDC-deterministic',...  % only start/stop tags
                       'TDC-tags-on-channel',...% frame tag stored on a TDC channel (#4 default)
                       'TDC-tags-on-channel2'};  % frame tag stored on a TDC channel (#4 default) and line gating of CFDs

    developping_types = supported_types([1 2]);
                   
    if ~ismember(lower(slice_type),lower(supported_types))
        error(['TYPE NOT SYPPORTED:' slice_type ])
    end
                   
    if ismember(lower(slice_type),lower(developping_types)) % temp code
        warning(['WARNING: thys slice types is still not fully supported'])
    end
    
    %%% THE FOLLOWING BLOCK IS EXECUTED IN ALL TYPES
    %   trim, exectue only this block
    
    %
    ptg = ptg - min(ptg) + 1; % reset  smaller pixel tag value

    % @WARNING I have difficulties to identify the stop clock
    % However, data after a stop is uncorreleted to the pixel number and,
    % therefore, a surrgate for a stop tag is the suddent decrease of pixel
    % count. There is a possibility for ambiguity when the pixel count goes
    % in overflow. I suppose the counter would resume from 0. This will
    % have to be fixed in future releases.
    
    stop_idx = find(chn==ELIS_CS_CLKTAG_STOP);
    if isempty(stop_idx)
        stop_idx = min(find(diff(ptg)<0));
    end
    if ~isempty(stop_idx)
        chn(stop_idx:end) = NaN;
    end
    
    % before acquisitions, spurious events may accumulate resulting in sections 
    % of invalid data. We can have an approximate estimation of this
    % block by detecting a jump in pixel number that exceed  those within a
    % frame
    start_idx = find(chn==ELIS_CS_CLKTAG_START);
    if isempty(start_idx)
        start_idx = min(find(diff(ptg(1:stop_idx-1))>n_pxl*n_lin));
    end
    if ~isempty(start_idx)
        chn(1:start_idx) = NaN;
    end
    
    %%% END OF "TRIM" BLOCK
    
    % b5
    %switch lower(slice_type)
    %   case 'tdc-tags-on-channel'
    %       % identify pixels (ptg values) that match frame clocks storedn in
    %       % channel #4 of the TDC            
    %       pxl_idx = [1 ptg(find(chn==3))]; 
    %end
    
    % remove invalid channels
    idx = find(chn<0  | chn>3 | isnan(chn));
    if ~isempty(idx)
        display('warning invalid channel numbers - data removed')

        ptg(idx)  = []; 
        utm(idx)  = []; 
        chn(idx)  = [];  

        min_ptg = min(ptg);
        ptg = ptg - min_ptg + 1;                        % reset initial pixel
    end

    
    switch lower(slice_type)
        case 'tdc-tags-on-channel'
        
            % b5
            % update frame clock pixel tags
            %if exist('min_ptg','var')
            %    pxl_idx (2:end) = pxl_idx (2:end) - min_ptg +1;
            %end
            
            %b6
            if nnz(chn==3)>0
                pxl_idx = find(chn==3);
                ptg_idx = [1 ptg(pxl_idx)]; 
                pxl_idx(find(diff(ptg_idx)<10))=[];            

                % b5
                %pxl_idx(find(diff(pxl_idx)<10))=[];

                %%%% use TDC channel 4to slice data stream
                n_frm = length(pxl_idx)-1;            

                % b5
                %for i=1:n_frm
                %    i
                %    frame_index(i,1) = min(find( ptg>=pxl_idx(i) ));
                %    frame_index(i,2) = max(find( ptg<pxl_idx(i+1)   ));
                %end

                %%b6
                frame_index(:,1) = [1 pxl_idx(1:end-1)-1];
                frame_index(:,2) = pxl_idx(1:end);
            else
                frame_index = -1;
            end
        case 'tdc-tags-on-channel2'
            
            %b6
            pxl_idx = find(chn==3);
            ptg_idx = [ptg(pxl_idx)]; 
            ptg_idx(find(diff(ptg_idx)<10))=[];           
            
            n_frm = length(ptg_idx)-1;            

            frame_index(:,1) = [1 ptg_idx(1:end-1)-1];
            frame_index(:,2) = ptg_idx(1:end);
            
            
        case 'tdc-deterministic'
            
            n_frm        = img_prm.f*img_prm.z;
            frame_length = (img_prm.x+img_prm.rx)*img_prm.y + img_prm.ry;% pixels
            stack_length = img_prm.z*(img_prm.x+img_prm.rx)*img_prm.y + img_prm.ry + img_prm.os;
      
            for i=1:1:n_frm 
                z = mod(i-1,img_prm.z)+1; % estimate slice #
                f = ceil(i/img_prm.z);    % estimate FoV #

                frame_index(i,1) = min(find(ptg>img_prm.ox+(i-1)*frame_length +(f-1)*img_prm.os));        
                frame_index(i,2) = max(find(ptg<img_prm.ox+    i*frame_length +(f-1)*img_prm.os));
            end
        
    end
    
    
    
