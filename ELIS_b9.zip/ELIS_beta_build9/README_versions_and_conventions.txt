NOTES: 
- convert tdc to object
- inspecting flow control data in order to fix the FLIM mdoality
- rewriting acquire to implement scanner 2 function




VERSIONS
--- beta 1.1 (b7)
- supporting gating of channels in TDC mode (gate by lie clock, record frame clock)

--- beta 1.0 (b6)
- this is a stable version used for the first experiments in the lab
- minor bug corrected
- DUMP2HD acquisition mode deprecated
- real-time processing of multipoint timelapse implemented

--- alpha 0.3 (b5)
- improved GUI supporting a status bar
- amended code for basic memory management and status bar usage
- support continous acquisition and FIFO data stream saved directly to HD
- support status timer and additional waiting bar for timing 
- support mutli-point time lapse
- early support of datastream slicing function with frame tagging on
  chennel 4; this and other slicing functions are yet to be optimized
- recoded histogramming function

--- alpha 0.2 (b4)
- improved speed of parsing
- read fifo now is always stable in TDC mode after avoiding premature exiting of the block
- added interrupt at the end of read fifo
- added data slicign function to support multi point volumte acquisitions

--- alpha 0.2 (b3)
- first GUI - fully functional

--- alpha 0.1 (b2)
added conventions
backbone of future public releases coded
added parsing of clock signals (0.0 was handling only pixel clock)
TDC modality is now fully functional and stable

--- alpha 0.0 (b1)
tested basic functionalities - first working software

***********************************

CONVENTIONS

--- ELIS_CS_CATEGORY_NAMEOFCONSTANT
names of constants 
category is optional

--- cs_nameofvariable
variables of particular importance for the entire software
these include variables that influence the complete workflow 

--- nameofidId
identifiers such as ticId, fileId, pipeId

--- h[f/a]_nameofhandler
handler or handler array
f: figures
a: axes
w: waitbars

*****************************

INLINE FUNCTIONS available within the main workspace

[x1 y1 x2 y2] = pos(n_line)*;           (elis_cs_gui_main)      defines position of GUI elements
[x1 y1 x2 y2] = posa(nline,ncol,icol)*; (elis_cs_gui_acquire)	defines position of GUI elements
[x1 y1 x2 y2] = posw(n_item)*;          (elis_cs_gui_waitbar)   defines position of GUI elements
   
cs_status(message)**            (elis_cs_gui_waitbar) send message to status bar (need hgui.w_main)                        
cs_waitbar(handle,value)*       (elis_cs_gui_waitbar) set waitbar value (supports hgui.memory and .fifo)
cs_waitbar_msg(handle,title)*   (elis_cs_gui_waitbar) set waitbar title (supports hgui.memory_txt and .fifo_txt)
cs_status_icon(value)**         (elis_cs_gui_waitbar) change status icon (ELIS_CS_STATUS_OK, ELIS_CS_STATUS_WARNING, ELIS_CS_STATUS_ERROR)

* can be moved to definition folder
* pos can be generalized, perhaps within an m-file (function)
* currently needs variables defined within the m-file