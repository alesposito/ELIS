% histogram - v10
% --- build 8
% - add QC on empty channels
%
% --- build 6
% - suport histrogramming of HD buffered data
% - spin-off of diplay function; still called from within this m-file, need
%   to change in the future

% --- build 5
% - hanlde status bar in GUI
% - supports frame tags on channel 4 (v8)
% - code fully reorganized
%
% --- build 4
% - recognized new frames also in TDC mode
% - fixed issue with leading wrong tags
% - makes use of external slicing function
%
% --- build 3
% - implementing support for FLIM mode
%
% --- build 2
% - full support of the TDC funcionalities using start and stop time tags
%   (v3 of this function)
% - preparing support of FLIM modality

%function img = elis_cs_histogram(ptg2, utm, chn, tag_idx, img_prm)

%% INITIALIZE

% initialize wait bar
cs_waitbar_msg(hgui.fifo_txt,'PROCESSING DATA');
cs_waitbar(hgui.fifo,0);
  
tichistId = tic;

display(['img_prm.y = ' num2str(img_prm.y) ' img_prm.x+img_prm.rx = ' num2str(img_prm.x+img_prm.rx) ' img_prm.ry = ' num2str(img_prm.ry) ' img_prm.oy = ' num2str(img_prm.oy) ' img_prm.ox = ' num2str(img_prm.ox)] )

supported_types = {'FLIM',...               % line and frame tags are stored in chn input as negative values
                   'trim',...               % only trime trailing and haders pixels
                   'TDC-single',...         % single image (possible multiple frame
                   'TDC-deterministic',...  % only start/stop tags
                   'TDC-tags-on-channel'};  % frame tag stored on a TDC channel (#4 default)

slice_type            = 5;
bResynchFrameHeurstic = 1;

%% Prepare data stream for histogramming

% reset initial pixel
ptg = ptg - min(ptg) + 1;            

% slice datastream  
[ptg, utm, chn, frame_idx] = elis_cs_slice_stream(ptg, utm, chn, img_prm, supported_types{slice_type});    

% bin/modulo operation on decays
utm = mod(utm, img_prm.t_mod);          % use modulto operation in order to cumulate (fold over) decays 
utm = ceil(utm/img_prm.t_binning)+1;    % binning time (reassign bin number)

%% histrogramming - init

img   = zeros([img_prm.x img_prm.y max(utm) img_prm.n_ch img_prm.f]);
%tmp = [];
tmp = img;
%tmp2 = [];
tmp2 = img;
n_frm = size(frame_idx,1);
i_fov = 0;

%@note for accumulation (e.g., extended focus) it is possible to speedup
%the algorithm histrogramming an antire fov block, but removing gap
%blocks. check v7 and v8. Currently,thisis not supported
n_slc=img_prm.z;

%%

for i=1:n_frm        

    % GUI
    display(['Processing frame ' num2str(i) ' of ' num2str(n_frm) ]);
    cs_waitbar(hgui.fifo,i/n_frm);
    cs_waitbar(hgui.memory,ae_memory); 
    drawnow
    
    % extract indivual frame from data stream
    ptg3 = ptg(frame_idx(i,1):frame_idx(i,2));
    utm3 = utm(frame_idx(i,1):frame_idx(i,2));
    chn3 = chn(frame_idx(i,1):frame_idx(i,2));
    
    % reset initial pixel
    ptg3 = ptg3 - min(ptg3) +1;
    
    switch slice_type
        case 4 % TDC-deterministic
            % Modulo operation for accumulation
            ptg3 = mod(ptg3,img_prm.x+img_prm.rx*img_prm.y+img_prm.ry)+1;
            % trim excess pixels (if slicing correct these will be just frame/stack retracing pixels)
            idx = ptg3>img_prm.x+img_prm.rx*img_prm.y;%    (assume retracing on trailing end)
        
        case 5
            % trim excess pixels (if slicing correct these will be just frame/stack retracing pixels)
            idx = (ptg3<max(ptg3)-(img_prm.x+img_prm.rx)*img_prm.y+1) | chn3>2;
    end
    
    if ~isempty(idx)
        ptg3(idx) = [];
        utm3(idx) = [];
        chn3(idx) = [];
        
        ptg3 = ptg3- min(ptg3) +1; 
    end    
 
    % histrogam individual frame, pad with zeros if missing pixels and
    % reshape to image format
    tmp = accumarray({ptg3,utm3,chn3+1},1);
    if size(tmp,1)<(img_prm.x+img_prm.rx)*img_prm.y
        tmp = cat(1,tmp,zeros((img_prm.x+img_prm.rx)*img_prm.y-size(tmp,1),size(tmp,2),size(tmp,3)));             
    end        
    tmp = reshape(tmp,[img_prm.x+img_prm.rx img_prm.y size(tmp,2) size(tmp,3)]);
    
    % trim line retracing pixels
    if bResynchFrameHeurstic
        x_proj  = sumch(tmp(:,:,:,:),[2 3 4]);    
        x_shift = find(x_proj==max(x_proj));         
        tmp     = circshift(tmp,[-x_shift 0 0 0]);
    end
    tmp = tmp(1:img_prm.x,:,:,:);

    % accumulate data @@ need revision
    if n_slc==1
        img(:,:,:,:,i) = tmp;
    else % accumulate in z, but not on f
        plane_id = mod(i-1,img_prm.z)+1;
        tmp2(:,:,:,:,plane_id) = tmp;
        if plane_id==n_slc
            i_fov = i_fov + 1; 
            try % added on top of v7
                img(:,:,:,:,i_fov) = sumch(tmp2,5); % this line is v7
            catch
                warning(['PLANE N.' num2str(plane_id) ' exhibits wrong dimensions: skipping...']) 
            end
            clear tmp2
        end
    end
end
clear tmp

toc(tichistId)

%% Compensate for different delays in each channel
decays   = sumch(img,[1 2 5]);
decays   = decays./repmat(max(decays),[size(decays,1) 1]);


t_shifts = zeros(img_prm.n_ch);
for i_ch=1:img_prm.n_ch
    try
        dpeaks   = mod(find(decays(:,i_ch)==1),size(decays,1));
        t_shifts(i_ch) = dpeaks-min(dpeaks);
    catch % b8 - QC on empty channels
        t_shifts(i_ch) = 0;
    end
end





for i_ch=1:img_prm.n_ch
    img(:,:,:,i_ch,:) = circshift(img(:,:,:,i_ch,:),-[0 0 t_shifts(i_ch) 0 0]);
end

img = sumch(img,5);

elis_cs_display;