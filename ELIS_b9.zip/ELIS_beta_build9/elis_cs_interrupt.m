function err = elis_cs_interrupt(tdcId)
    
    err = elis_cs_check_err(calllib('scTDC1','sc_tdc_interrupt2',tdcId));    
    
    display(['Acquisition stopped']); 