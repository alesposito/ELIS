% ELIS CS - ACQMAN

for it=1:img_prm.t
    % start acquisition
    elis_cs_acquire(tdcId, img_prm.acq_t, gpx3ini, img_prm);
    % read buffer
    elis_cs_read_fifo;
    
    
    if it<img_prm.t                
        while toc(ticReadFIFOok)<img_prm.lag_t*60-1            
            cs_waitbar_msg(hgui.elapsed_txt,['WATING FOR NEXT TIME POINT ' num2str(toc(ticReadFIFOok)-img_prm.lag_t*60) ' seconds'])
            cs_waitbar(hgui.elapsed,1-toc(ticReadFIFOok)/(img_prm.lag_t*60))
            pause(1)                
        end        
    end
end

cs_waitbar_msg(hgui.elapsed_txt,'---')
cs_waitbar(hgui.elapsed,0)